# Convex tutorial

You're just a few minutes away from having a chat app powered by Convex.

Follow the tutorial at
[docs.convex.dev/tutorial](https://docs.convex.dev/tutorial) for instructions.
